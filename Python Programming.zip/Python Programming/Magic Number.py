# Write a program to display all magic number from 9 to 99

print("The magic numbers are: ")
for k in range (9,100):
    num=k
    while (True):
        sum=0
        if num<10:
            break
        while num>0:
            sum+=num%10 #(sum=sum+remainder)
            num//=10
        num=sum
    if num==1:
        print(k, end="  ")
