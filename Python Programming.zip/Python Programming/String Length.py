# Write a program to calculate length of a string

str1=str(input("Enter a string: "))
c=0
for i in str1:
    c=c+1
print("Length of the string",c)
