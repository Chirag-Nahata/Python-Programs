# Write a program to input a string and print the string that capitalize every alternate letter in the string 
s = str(input("Enter your string: "))
s1 = ''
for i in range(0,len(s)):
    if i%2 != 0:
        s1 += s[i].upper()
    else:
        s1 += s[i].lower()
print(s1)
