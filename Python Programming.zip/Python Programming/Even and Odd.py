#write a program to input a anumber and check it is even number or odd number

n=int(input("Enter a number : "))
if n%2==0:
    print("This number is Even")
else:
    print("This number is Odd") 
    
