# Write a number and check whether it is armstrong or not.

num = int(input("Enter a number: "))  
sum = 0  
arm = num  
  
while arm > 0:  
   digit = arm % 10  
   sum += digit ** 3  
   arm //= 10  
  
if num == sum:  
   print(num,"is an Armstrong number")
else:  
   print(num,"is not an Armstrong number")  
