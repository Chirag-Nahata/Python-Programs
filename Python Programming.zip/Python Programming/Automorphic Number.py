# Write a python program to check whether a number is Automorphic Number

num=int(input("Enter a number:"))
sqr=num*num
f=0
while num!=0:
    if(num%10 != sqr%10):
       f=-1
       break
    num=int(num/10)
    sqr=int(sqr/10)
if(f==0):
   print("It is an Automorphic Number")
else:
   print("It is not an Automorphic Number")
