print(" K= Kolkata\n M=Mumbai\n C=Chennai\n D= Delhi")
city=input("Enter city name: ")
weight=float("Enter the weight of the parcel: ")
if city=='K':
    if weight <= 100:
        charges= weight*45
    else:
        charges=weight*75
    print("Charges= ",charges)
elif city=='M':
    if weight <= 100:
        charges= weight*65
    else:
        charges=weight*95
    print("Charges= ",charges)
elif city=='C':
    if weight <= 100:
        charges= weight*75
    else:
        charges=weight*115
    print("Charges= ",charges)
elif city=='D':
    if weight <= 100:
        charges= weight*90
    else:
        charges=weight*120
    print("Charges= ",charges)
else:
    print("Invalid city name")
 
    

        
