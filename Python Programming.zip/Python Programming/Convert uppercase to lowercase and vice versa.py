# Write a program to make the lowercase letters uppercase and uppercase letters to lowercase. 

s=input("Enter the words: ")
new_str=s.swapcase()
print(new_str)
        
