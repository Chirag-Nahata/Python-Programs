# Write a program to input a string and remove vowels from the string
str1 = str(input("Enter any string: "))
str2=""
for i in range(len(str1)):
    if str1[i] not in "AEIOUaeiou":
        str2=str2+str1[i]
print(str2);
