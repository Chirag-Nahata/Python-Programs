# Write a program to input a string and calculate the number of uppercase letter and lowercase letter and digits

str1=str(input("Enter a string: "))
u=0)
l=0
n=0
for i in str1:
    if i.islower():
        l=l+1
    if i.isupper():
        u=u+1
    if i.isdigit():
        n=n+1
print("Number of lowercase character: ",l)
print("Number of lowercase character: ",u)
print("Number of number: ",n)
