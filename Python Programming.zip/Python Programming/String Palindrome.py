# Write a program to input a string check whether it is palindrome or not
x=str(input("Enter a string: "))
w=""
for i in x:
    w = i + w
if (x == w):
    print("The string is a palindrome!")
else:
    print("The string isn't a palindrome!")
