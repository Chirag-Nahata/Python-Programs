#Write a program to find the sums of the series:

s=0
k=1
for i in range (1,11):
     k=k*i
     s=s+k
print(s)


