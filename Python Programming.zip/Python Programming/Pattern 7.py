#Write a program to print the following pattern:
#10   
#11 12
#13 14 15
#16 17 18 19
#20 21 22 23 24

n= int(input("Enter the number of rows: "))
k=10
for i in range(1, n+1):  
    for j in range(1, i + 1):  
        print(k, end='  ')
        k=k+1
    print()
