#Write a program to find the sums of the series:

s=0
for i in range (1,20):
    s=s+i*(i+1)
print(s)
    
    
