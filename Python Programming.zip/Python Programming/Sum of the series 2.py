# Write a program to compute and display the sum of the following series: s = 1+2/1*2 + 1+2+3/1*2*3 + ..... + 1+2+3+ ..... +n /1*2*3.....*n.

n=int(input("Enter a number: "))
s=0
p=1
q=1
for i in range (2,n+1):
    p=p+i
    q=q*i
    s=s+(p/q)
print("Result = ",s)
