# Write a program to calculate sum of n natural numbers

n=int(input("Enter a number: "))
sum=0
for i in range (1,n+1):
    sum=sum+i
print("Sum of n natural number is ", sum)
 

 