n= int(input("Enter a two digit number: "))
a=(int)(n/10)
b=n%10
c=a+b
d=a*b
e=c+d
if n==e:
    print("This is a special two digit number")
else:
    print("This is not a special two digit special number")
