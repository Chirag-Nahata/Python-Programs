# Write a program to input a string and count number of vowels 

str1=str(input("Enter a string: "))
v=0
for i in str1:
    if i in('A','E','I','O','U','a','e','i','o','u'):
        v=v+1
print("Number of vowels: ",v)
