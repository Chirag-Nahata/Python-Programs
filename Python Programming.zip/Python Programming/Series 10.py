#Write a program to find the sums of the series:

n = int(input("Enter a number: "))
r = 0
for i in range(1, n+1):
    r = r+(i/(i+1))
print("Result = ",r)
