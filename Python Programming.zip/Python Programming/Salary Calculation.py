name=input("Enter employee name: ")
bs=float(input("Enter the salary: "))
da=(bs*25)/100
hr=(bs*15)/100
pf=(bs*8.3)/100
gs=(bs+da+hr)
np=(gs-pf)
print("Gross Salary= ",gs)
print("Net Salary= ",np)


