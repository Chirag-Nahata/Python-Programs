name=input("Enter the name of the customer: ")
number=input("Enter the customer number: ")
units=float(input("Enter the units consumed: "))
if units<=100:
    charges=units*4.80
elif units<=300 and units>100:
    charges=(100*4.80)+((units-100)*5.50)
elif units<=600 and units>300:
    charges=(100*4.80)+(200*5.50)+((units-300)*6.80)
else:
    charges=(100*4.80)+(200*5.50)+(300*6.80)+((units-600)*7.50)
print("Charges= ",charges)
    

