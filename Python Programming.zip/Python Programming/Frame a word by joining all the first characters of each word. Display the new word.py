# Write a program to enter a string and frame a word by joining all the first characters of each word. Display the new word.

str=input("Enter a string: ")
str=" "+str
str1=""
c=0
for i in str :
    if i == " " :
        str1 = str1 + str [ c+1 ]
    c=c+1
print (str1)
