n=int(input("Enter a number: "))
s=0
while n>0:
    i=n%10
    n=n//10
    if i!=0:
        s=s*10+i
while s>0:
    i=s%10
    s=s//10
    n=n*10+i
print(n)
