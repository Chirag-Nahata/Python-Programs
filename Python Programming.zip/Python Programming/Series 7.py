#Write a program to find the sums of the series:

n=int(input("Enter value of n: "))
s=0
t=0
for i in range(1,n+1):
    t=t+i
    s=s+t
print(s)
