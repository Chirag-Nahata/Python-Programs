# Write a program to input a number and check whether it is happy or sad number.

# 23 = 2^2 + 3^2 = 4+9 = 13 = 1^2 + 3^2 = 1+9 = 10 = 1^2 + 0^2 = 1+0 = 1. Therfore, it is a happy number.
# 11 = 1^2 + 1^2 = 1+1 = 2. Therfore, it is a sad number.
# 13 = 1^2 + 3^2 = 1+9 = 10 = 1^2 + 0^2 = 1+0 = 1. Therfore, it is a happy number.

num=int(input("Enter the number: "))
result=num
def isHappyNumber(num):    
    rem = sum = 0;    
    while(num > 0):    
        rem = num%10;    
        sum = sum + (rem*rem);    
        num = num//10;    
    return sum;    
while(result != 1 and result != 4):    
    result = isHappyNumber(result);    
if(result == 1):    
    print(str(num) + " is a happy number")   
elif(result == 4):    
    print(str(num) + " is not a happy number")
