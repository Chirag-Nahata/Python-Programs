#Write a program to find out whether or not two strings contain same characters

a=str(input("Enter the first string: "))
b=str(input("Enter the second string: "))
if(len(a)==len(b)):
     print ("They have equal number of chracters")
else :
     print ("They dont have equal number of chracters")
