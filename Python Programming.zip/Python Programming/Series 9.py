#Write a program to find the sums of the series:

n = int(input("Enter a number: "))
r = 0
p =1
for i in range(1,n+1):
    p = (p*i)
    r = r+p
print("Result = ",r)
