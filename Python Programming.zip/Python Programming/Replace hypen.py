#Write a python program to take in a string and replace every blank space with hyphen

str1 = input("Please the string: ")
str2 = ''
for i in range(len(str1)):
    if(str1[i] == ' '):
        str2 = str2 + '-'
    else:
        str2 = str2 + str1[i]
print("Modified String : ",str2)
