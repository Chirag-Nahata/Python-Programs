#Write a program to check whether a number is a Special Number or not 
n=int(input("Enter a number: "))  
sum=0  
temp=n  
while(n):   
    i=1  
    fact=1  
    rem=n%10  
    while(i<=rem):  
        fact=fact*i 
        i=i+1  
    sum=sum+fact  
    n=n//10  
if(sum==temp):  
    print(" The number is a special number")  
else:  
    print("The number is not a special  number")
