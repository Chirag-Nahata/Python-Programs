# Write a program to find the sum of the series S = a + a/2! + a/3! + ..... + a/n!

n = int(input("Enter a number: "))
a = int(input("Enter another number: "))
r = 0
p =1
for i in range(1, n+1):
    p = (p*i)
    r = r+(a/p)
print("Result = ",r)
