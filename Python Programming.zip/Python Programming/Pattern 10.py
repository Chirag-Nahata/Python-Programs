#Write a python program to display the following pattern:

#12345
#33345
#44445
#55555

n=int(input("Enter the number of rows: "))
for i in range(1,n+1):
    for j in range(1,n+1):
        if j <= i:
            print(i,end=' ')
        else:
            print(j,end=' ')
    print()
