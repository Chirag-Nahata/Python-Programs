# Write a program to find the sum of the series
a=int(input("Enter a number: "))
n=int(input("Enter another number: "))
s=0
for i in range (1,n+1,2):
    s=s+(a+i)/(i+1)
print(s)
