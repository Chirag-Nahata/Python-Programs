# Write a program to find the sum of the series of S=2/3 - 4/5 + 6/7 - 8/9 + ..... to n.

n=int(input("Enter a number: "))
s=0
k=1
for i in range (2,n+1,2):
    s=s+(i/(i+1))*k
    k=(k*-1)
print("Result = ",s)


    
    
    
