# Write a program to accept a number and check whether it is a "Twisted Prime" .

num=int(input("Enter the number: "))
if num > 1:  
   for i in range(2,num):  
       if (num % i) == 0:
            f=1           
if f==1:
    rev=0
    flag=0
    while(num>0):
        dig=num%10
        rev=rev*10+dig
        num=num//10
    for i in range(2, rev//2):
        if ((rev % i) == 0):
            flag = 1
        break
    if (flag == 0):
        print("Twisted Prime")
    else:
        print("Not Twisted Prime")
else:
    print("Not Twisted Prime")


