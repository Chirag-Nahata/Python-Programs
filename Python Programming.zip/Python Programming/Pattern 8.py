# Write a program to input a number 0 or 1 if the user enters 0 then it will print 1 and if the user enters 1 then it will print 0 (without if else).

