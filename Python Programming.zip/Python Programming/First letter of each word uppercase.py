# Write a program to make the first letter of each word uppercase

string = input("Enter the line: ")
print("After capitalizing first letter: ", str.title(string))
