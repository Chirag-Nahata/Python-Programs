# Write a program to input a number and print sum of digits

n=int(input("Enter a number: "))
sum=0
while n>0:
    r=n%10
    n=n//10
    sum=sum+r
print("Sum of digits is ",sum)
