# Write a program that reads a line and count how many times a sub string appears in the line.

str1 = str(input("Enter a string : "))
str2 = str(input("Enter a sub-string : "))
print()
print(str1.count(str2))
print()
