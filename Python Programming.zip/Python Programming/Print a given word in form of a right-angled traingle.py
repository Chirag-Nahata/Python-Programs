# Write a program to print a given word in form of a right-angled traingle

str1 = str(input("Enter the string: "))  
x = ""  
for i in str1:  
    x += i  
    print(x)

