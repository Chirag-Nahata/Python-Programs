# Write a program to input a string and count how many words are there in the string
str1=str(input("Enter a string: "))
s=str1.split()
c=0
for i in range (len(s)):
    c=c+1
print("Number of words: ",c)
