# Write a menu driven program to find the area of circle, rectangle, square.

while True :
    name=input("Enter the name of the shape(Rectangle,Circle,Square)(If you want to exit, please type 'Exit') : ")
    if name == "Rectangle":
        l = int(input("Enter rectangle's length: "))
        b = int(input("Enter rectangle's breadth: "))
        rect_area = l * b
        print("The area of rectangle is ",rect_area)
    elif name == "Square":
        s = int(input("Enter square side's length: "))
        squ_area = s*s
        print("The area of rectangle is ",squ_area)
    elif name == "Circle":
        r = int(input("Enter circle's radius: "))
        pie = 22/7
        circle_area = pie*(r^2)
        print("The area of circle is ",circle_area)
    elif name == "Exit":
        break
    else:
        print("Please enter the required shape. Your shape does not match")

