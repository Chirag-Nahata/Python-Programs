#Write a program to find the sum of the series :

n=int(input("Enter a number: "))
k=1
s=0
for i in range (2,n+1,2):
    s=s+i*k
    k=k*(-1)
print(s)
