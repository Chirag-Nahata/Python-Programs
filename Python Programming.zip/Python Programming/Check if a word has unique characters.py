# Write a program to check if a string contains all unique characters.

def check_unique(str):
  for i in range(len(str)):
    for j in range(i + 1,len(str)):
      if(str[i] == str[j]):
        return False
  return True
str = input("Enter a string: ")
if(check_unique(str)):
  print("The string ",str," contains unique characters")
else:
  print("the string ",str," contains duplicate characters")
