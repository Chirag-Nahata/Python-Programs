# Write a program to remove all instance of a character from a string

n=str(input("Enter the line:"))
w=str(input("Enter the word:"))
print (n.replace(w,""))
