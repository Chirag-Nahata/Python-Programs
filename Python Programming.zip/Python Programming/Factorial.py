# Write a program to find the factorial of that number

n=int(input("Enter a number: "))
f=1
for i in range (1, n+1):
    f=f*i
print("The factorial of the number is: ", f)
    
