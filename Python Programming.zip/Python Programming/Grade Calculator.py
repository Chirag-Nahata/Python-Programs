name=input("Enter the Student name: ")
marks=int(input("Enter the average marks: "))
if marks>=80:
    print("Distinction")
elif marks>=60 and marks<80:
    print("First Division")
elif marks>=45 and marks<60:
    print("Second Division")
elif marks>=40 and marks<45:
    print("Pass")
else:
    print("No Grade")
