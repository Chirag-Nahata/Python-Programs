#Write a program to check if the number is neon or not:
n=int(input("Enter the number : "))
s=(n*n)
a=s%10
b=s//10
c=(a+b)
if (c==n):
     print ("The number is a neon number ")
else:
     print ("The number is not a neon number ")
