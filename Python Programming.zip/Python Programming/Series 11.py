#Write a program to find the sums of the series:

n = int(input("Enter a number: "))
r = 0
p = 1
q = 1
for i in range(1,n+1,2):
    r = r+(p/q)
    p = p+2
    q = q+p
print("Result = ",r)
