# Write a program to check whether the numbers are twin prime or not.

a = int(input("Enter the number: "))
b = int(input("Enter the other number: "))
if num > 1:  
   for i in range(2,num):  
       if (num % i) == 0: 
    if a-b == 2 or a-b == -2:
        print ("They are Twin Primes")
    else :
        print ("They are not Twin Primes")
else :
    print ("They are not Prime Numbers")
