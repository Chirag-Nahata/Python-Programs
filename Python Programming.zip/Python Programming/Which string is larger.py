# Write a program to input two strings and dispaly the larger length string

str1=str(input("Enter a string: "))
str2=str(input("Enter another string: "))
l=0
a=0
for i in str1:
    l=l+1
for i in str2:
    a=a+1
if l>a :
    print("The larger string is: ",str1)
elif l<a :
    print("The larger string is: ",str2)
else:
    print("Both the lengths of the strings are equal")
